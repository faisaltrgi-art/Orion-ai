"""Celery configuration."""
from celery import Celery
from app.core.config import settings

celery_app = Celery(
    "orion_ai",
    broker=settings.redis_url,
    backend=settings.redis_url,
    include=["app.services.ai_tasks"]
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_time_limit=300,
    worker_prefetch_multiplier=1,
)
